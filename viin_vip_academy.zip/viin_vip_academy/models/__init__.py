# -*- coding: utf-8 -*-

from . import education_class_vip
from . import education_student